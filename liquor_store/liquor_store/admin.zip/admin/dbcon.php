<?php
$con = mysqli_connect("localhost","mrstnbfg_mis","Mis@tkay2022","mrstnbfg_mis");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>